<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name = 'vipindonesia';
$db = new MySQL($host,$user,$pass,$name);
?>