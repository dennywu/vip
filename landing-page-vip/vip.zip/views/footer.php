<footer class="mod-footer">
            <div class="footer-top">
                <div class="grid_frame">
                    <div class="container_grid clearfix">
                        <div class="grid_4">
                            <div class="company-info">
                                <img src="images/logo.png" alt="VIP Card Indonesia"/>
                                <p class="rs">CV Mitra Batam Sejahtera</p>
                            </div>
                        </div>
                        <div class="grid_4">
                            <div class="block social-link">
                                <h3 class="title-block">Follow us</h3>
                                <div class="block-content">
                                    <ul class="rs">
                                        <li>
                                            <i class="fa fa-facebook-square fa-2x"></i>
                                            <a href="#" target="_blank">Our Facebook page</a>
                                        </li>
                                        <li>
                                            <i class="fa fa-twitter-square fa-2x"></i>
                                            <a href="#" target="_blank">Follow our Tweets</a>
                                        </li>
                                        <li>
                                            <i class="fa fa-pinterest-square fa-2x"></i>
                                            <a href="#" target="_blank">Follow our Pin board</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div><!--end: Follow us -->
                        <div class="grid_4">
                            <div class="block intro-video">
                                <h3 class="title-block">Intro Video</h3>
                                <div class="block-content">
                                    <div class="wrap-video" id="sys_wrap_video">
                                        <div class="lightbox-video">
                                                <a class="html5lightbox" href="https://www.youtube.com/watch?v=q02D0UW4V60" title=""><i class="btn-play"></i><img src="images/video-img.png" alt="video vip card indonesia"></a>     
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </div><!--end: Intro Video -->
                        <!--<div class="grid_3">
                            <div class="block blog-recent">
                                <h3 class="title-block">Latest News</h3>
                                <div class="block-content">
                                    <div class="entry-item flex">
                                        <a class="thumb-left" href="#">
                                            <img src="images/ex/04-15.jpg" alt="$TITLE"/>
                                        </a>
                                        <div class="flex-body"><a href="#">Apa manfaat dari VIP Card ?</a></div>
                                    </div>
                                    <div class="entry-item flex">
                                        <a class="thumb-left" href="#">
                                            <img src="images/ex/04-16.jpg" alt="$TITLE"/>
                                        </a>
                                        <div class="flex-body"><a href="#">Kemudahan untuk mendapatkan informasi discount</a></div>
                                    </div>
                                </div>
                            </div>
                        </div><!--end: blog-recent -->
                    </div>
                </div>
            </div><!--end: .foot-top-->
            <div class="foot-copyright">
                <div class="grid_frame">
                    <div class="container_grid clearfix">
                        <div class="left-link">
                            <a href="index.php">Home</a>
                            <a href="about.php">About Us</a>
                            <a href="contact.php">Contact Us</a>
                        </div>
                        <div class="copyright">

                            Copyright &copy; 2014 by www.vip-indonesia.com
							<br/>
							<span> Visitor : </span>
							<!-- Start of StatCounter Code for Default Guide -->
							<script type="text/javascript">
							var sc_project=10252939; 
							var sc_invisible=0; 
							var sc_security="c1adc039"; 
							var scJsHost = (("https:" == document.location.protocol) ?
							"https://secure." : "http://www.");
							document.write("<sc"+"ript type='text/javascript' src='" +
							scJsHost+
							"statcounter.com/counter/counter.js'></"+"script>");
							</script>
							<noscript><div class="statcounter"><a title="free web stats"
							href="http://statcounter.com/" target="_blank"><img
							class="statcounter"
							src="http://c.statcounter.com/10252939/0/c1adc039/0/"
							alt="free web stats"></a></div></noscript>
							<!-- End of StatCounter Code for Default Guide -->
                        </div>
                    </div>
                </div>
            </div>
        </footer>